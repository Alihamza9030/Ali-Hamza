
import java.util.Scanner;

public class Task02 {
public static void main (String[] args){


    try {
    Scanner sc=new Scanner(System.in);
    int f1,f2;
        System.out.println("Wellcome to the Division Game");
        System.out.println("Enter fisrt value");
        f1 = sc.nextInt();
        System.out.println("Enter Second value");
        f2 = sc.nextInt();
    float ans= f1/f2;
    System.out.println("The result of divisiom is = "+ans);
        System.out.println("Ali Hamza Roll No 2019-SE-219");
    }catch (ArithmeticException e){
        System.out.println("Number is not divided by 0");
    }
       catch (Exception ex ){
           System.out.println("Invalid Num enetred by user");   
       }
    
    }
   
    
}    

