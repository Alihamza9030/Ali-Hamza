import java.util.Scanner;
public class Task01{
     public static void main(String[] args){
        int a[]=new int[10],i,num;
        for(i=0;i<10;i++){
            a[i]=1+(int)+(Math.random()*100);}
            System.out.println("enter aaray index number to search");
            Scanner s =new Scanner(System.in);
            num=s.nextInt();
         System.out.println("Ali Hamza Roll No 2019-SE-219");
            try{
            System.out.println("Value found on given index is"+a[num]);    
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.println("index not found");
            }
     }
}